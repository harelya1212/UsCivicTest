
# Cloud Functions — Weekly Updater & Questions Seeder

## Commands
npm install
npm run build
firebase deploy --only functions

## Functions
- updateOfficials (HTTP): replaces Officials + Representatives from either external URLs or Cloud Storage JSON files in `data/`.
- weeklyOfficialsUpdater (Scheduled): runs every Sunday 03:00 and updates from Cloud Storage JSON.
- seedQuestionsFromUSCIS (HTTP): seeds the `Questions` collection using the JSON at `data/questions_128.json` (preferred). Optionally parse the USCIS PDF.

## Storage layout (recommended)
- gs://YOUR_BUCKET/data/questions_128.json
- gs://YOUR_BUCKET/data/officials_full.json
- gs://YOUR_BUCKET/data/representatives_full.json

