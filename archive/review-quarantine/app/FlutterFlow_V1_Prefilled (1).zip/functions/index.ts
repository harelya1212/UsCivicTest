
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import fetch from 'node-fetch';
// @ts-ignore: optional import if you choose to parse PDF
// import pdf from 'pdf-parse';

admin.initializeApp();
const db = admin.firestore();

/**
 * HTTP: /updateOfficials
 * Body (JSON): {
 *   officialsUrl?: string, // optional: https URL to a JSON {state, role, name}
 *   repsUrl?: string       // optional: https URL to a JSON {state, district, name, party}
 * }
 * If not provided, the function will read from Cloud Storage: /data/officials_full.json and /data/representatives_full.json
 */
export const updateOfficials = functions.https.onRequest(async (req, res) => {
  try {
    const officialsUrl = req.body?.officialsUrl;
    const repsUrl = req.body?.repsUrl;

    let officials:any[] = [];
    let reps:any[] = [];

    if (officialsUrl) {
      const r = await fetch(officialsUrl); officials = await r.json();
    } else {
      const file = admin.storage().bucket().file('data/officials_full.json');
      const [buf] = await file.download(); officials = JSON.parse(buf.toString());
    }

    if (repsUrl) {
      const r2 = await fetch(repsUrl); reps = await r2.json();
    } else {
      const file2 = admin.storage().bucket().file('data/representatives_full.json');
      const [buf2] = await file2.download(); reps = JSON.parse(buf2.toString());
    }

    const officialsCol = db.collection('Officials');
    const repsCol = db.collection('Representatives');

    const batch = db.batch();

    // Wipe & replace (simple approach)
    const snapOff = await officialsCol.get(); snapOff.forEach(d=>batch.delete(d.ref));
    const snapReps = await repsCol.get(); snapReps.forEach(d=>batch.delete(d.ref));

    // Write officials
    officials.forEach((o:any) => {
      const ref = officialsCol.doc();
      batch.set(ref, {state:o.state, role:o.role, name:o.name, verifiedAt: admin.firestore.FieldValue.serverTimestamp()});
    });

    // Write reps
    reps.forEach((r:any) => {
      const ref = repsCol.doc();
      batch.set(ref, {state:r.state, district:r.district, name:r.name, party:r.party});
    });

    await batch.commit();
    res.json({ok:true, officials: officials.length, representatives: reps.length});
  } catch (e:any) {
    console.error(e);
    res.status(500).json({ok:false, error: e.message});
  }
});

/**
 * Scheduled weekly Sunday 3:00 AM (timezone can be set in scheduler)
 * Invokes updateOfficials reading from Storage JSON files.
 */
export const weeklyOfficialsUpdater = functions.pubsub.schedule('every sunday 03:00').onRun(async () => {
  const url = functions.config().app?.updater_url; // optional
  if (url) {
    await fetch(url, {method:'POST'});
  } else {
    // call local logic: read from storage and update
    await updateOfficialsImpl();
  }
  return null;
});

async function updateOfficialsImpl(){
  const file = admin.storage().bucket().file('data/officials_full.json');
  const [buf] = await file.download(); const officials = JSON.parse(buf.toString());
  const file2 = admin.storage().bucket().file('data/representatives_full.json');
  const [buf2] = await file2.download(); const reps = JSON.parse(buf2.toString());
  const officialsCol = db.collection('Officials');
  const repsCol = db.collection('Representatives');
  const batch = db.batch();
  const snapOff = await officialsCol.get(); snapOff.forEach(d=>batch.delete(d.ref));
  const snapReps = await repsCol.get(); snapReps.forEach(d=>batch.delete(d.ref));
  officials.forEach((o:any)=> batch.set(officialsCol.doc(), {state:o.state, role:o.role, name:o.name, verifiedAt: admin.firestore.FieldValue.serverTimestamp()}));
  reps.forEach((r:any)=> batch.set(repsCol.doc(), {state:r.state, district:r.district, name:r.name, party:r.party}));
  await batch.commit();
}

/**
 * OPTIONAL: Seed 128 USCIS questions directly from the official PDF (M‑1778).
 * For reliability and lower cold-start, we suggest maintaining a JSON at /data/questions_128.json.
 * If you want to parse the PDF at runtime, uncomment pdf-parse import and add it to package.json.
 */
export const seedQuestionsFromUSCIS = functions.https.onRequest(async (req, res) => {
  try {
    const pdfUrl = req.body?.pdfUrl || 'https://www.uscis.gov/sites/default/files/document/questions-and-answers/2025-Civics-Test-128-Questions-and-Answers.pdf';
    const r = await fetch(pdfUrl);
    const arrayBuffer = await r.arrayBuffer();
    // const parsed = await pdf(Buffer.from(arrayBuffer));
    // const text = parsed.text;
    // TODO: implement robust parsing (regex for numbered lines). For now, read from Storage JSON for deterministic seeding.
    const file = admin.storage().bucket().file('data/questions_128.json');
    const [buf] = await file.download();
    const items = JSON.parse(buf.toString());

    const col = db.collection('Questions');
    // Replace all
    const snap = await col.get();
    const batch = db.batch();
    snap.forEach(d=>batch.delete(d.ref));

    items.forEach((q:any)=>{
      const ref = col.doc(String(q.uscisId).padStart(3,'0'));
      batch.set(ref, q);
    });

    await batch.commit();
    res.json({ok:true, seeded: items.length});
  } catch (e:any) {
    console.error(e); res.status(500).json({ok:false, error:e.message});
  }
});
