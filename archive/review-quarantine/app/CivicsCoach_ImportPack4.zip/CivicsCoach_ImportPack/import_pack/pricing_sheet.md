# Pricing & Plans

## Free (Ad‑Supported)
- Full 128‑question practice with USCIS 2025 stop‑rule (12/9)
- Adaptive drills + Visual Feedback pane
- Family space + Coach View (basic)
- Audio links (Spotify/YouTube)
- **Ads at natural breaks only** (interstitials after sessions), optional rewarded ads for +5 boosters

## Premium (One‑time purchase — No Ads)
- Remove all ads
- **Offline Mode**: weekly pack download (audio + visuals + quizzes)
- Coach View (advanced insights)
- Theme packs (optional)

### Notes
- iOS: use In‑App Purchase (non‑consumable) for Premium
- Android: use Play Billing (one‑time)
- ATT prompt on iOS if tracking is used for ads; respect user choice
- Families policy tags for under‑18 profiles