# app-ads.txt — Quick Setup

1) Pick a developer website domain (e.g., https://yourdomain.com) and ensure it is shown on your App Store / Play listing.
2) Create /app-ads.txt at the site root with your authorized sellers (e.g., `google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0`).
3) In AdMob, open your app → App settings → App-ads.txt → Verify domain. Fix any crawl issues.
4) For iOS, ensure the App Store “Marketing URL” points to the same domain so AdMob can verify. For Android, link the site in Play Console.
5) Monitor AdMob status until verified.