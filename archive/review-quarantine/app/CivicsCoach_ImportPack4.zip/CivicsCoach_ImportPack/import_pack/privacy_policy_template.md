# Privacy Policy (Starter)

We collect minimal information to run your study plan: account email, state, settings (fonts/theme), and study progress. We do **not** sell personal data.

Advertising (free tier): We use third‑party SDKs to show ads. On iOS, we ask for App Tracking Transparency (ATT) consent before using tracking‑based ads; if declined, we respect your choice. On Android, ads comply with Google Play policies and Families guidelines when applicable.

Purchases: Premium is a one‑time purchase processed by Apple or Google. We do not store payment card data.

Audio links: Opening Spotify/YouTube follows their privacy policies.

Data rights: You can export or delete your data from Settings.

Contact: privacy@yourdomain.com