
# Civics Coach (Family) — Import Pack

This bundle contains templates and content to get your app ready fast:

1. `civics_128_mc_TEMPLATE.csv` — schema for the **128 USCIS 2025 civics questions** (MC‑4). Paste the full 128 rows you already approved into this file, or import the CSV you saved earlier. Source: USCIS 2025 Civics Test (M‑1778).  
2. `visuals_manifest.csv` — one visual per question (filename + alt text). Use with the **Visuals Mapper** admin page.  
3. `visuals_placeholders_calm.zip` — Calm‑style placeholder PNGs matching every filename referenced by the manifest. Upload in Admin → Assets.  
4. `notifications_copy_deck.txt` — copy for daily push/email and weekly digest.  
5. `pricing_sheet.md` — free (ad‑supported) vs premium (one‑time) plan.  
6. `store_metadata_ios.txt` — App Store Connect listing text (title/subtitle/desc), review notes, privacy pointers.  
7. `store_metadata_android.txt` — Google Play listing text (short/full desc), Data safety hints.  
8. `privacy_policy_template.md` — editable privacy policy starter.  
9. `app_ads_txt_instructions.md` — step‑by‑step to verify **app-ads.txt** (AdMob) and Families settings.

**Import order**
1) Admin → Assets → Upload everything from `visuals_placeholders_calm.zip`.  
2) Admin → Visuals Mapper → upload `visuals_manifest.csv` → Dry‑Run → Apply.  
3) Admin → Questions → Bulk Import → use your final `civics_128_mc.csv` (or open the TEMPLATE and paste your 128 lines).  

**USCIS rules to respect**  
• Use the **2025** list (128 items).  
• Mixed practice stops at **12 correct** or **9 incorrect**.  
• 65/20 track asks 10 from marked questions; pass at 6.  
• Dynamic offices (President, VP, Speaker, Chief Justice, Governor, your Senators/Rep) must come from Admin → Test Updates.

