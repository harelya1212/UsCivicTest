
### 03_Data (גיליונות ותבניות)
- visuals_manifest_template.csv  ← תבנית מוכנה להדבקה ל‑Google Sheets (File → Import), או לעבוד ישירות בקובץ CSV ואז להמיר ל‑JSON.
- לינק לפתיחת Google Sheet חדש: https://docs.google.com/spreadsheets/create
